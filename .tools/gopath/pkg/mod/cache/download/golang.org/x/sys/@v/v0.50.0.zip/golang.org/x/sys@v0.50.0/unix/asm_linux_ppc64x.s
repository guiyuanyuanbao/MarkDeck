// Copyright 2014 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

//go:build linux && (ppc64 || ppc64le) && gc

#include "textflag.h"

//
// System calls for ppc64, Linux
//

// Just jump to package syscall's implementation for all these functions.
// The runtime may know about them.

TEXT ·Syscall(SB),NOSPLIT,$0-56
	MOVD	$syscall·Syscall(SB), R12
	MOVD	R12, CTR
	JMP	(CTR)

TEXT ·Syscall6(SB),NOSPLIT,$0-80
	MOVD	$syscall·Syscall6(SB), R12
	MOVD	R12, CTR
	JMP	(CTR)

TEXT ·SyscallNoError(SB),NOSPLIT,$0-48
	BL	runtime·entersyscall(SB)
	MOVD	a1+8(FP), R3
	MOVD	a2+16(FP), R4
	MOVD	a3+24(FP), R5
	MOVD	R0, R6
	MOVD	R0, R7
	MOVD	R0, R8
	MOVD	trap+0(FP), R9	// syscall entry
	SYSCALL R9
	MOVD	R3, r1+32(FP)
	MOVD	R4, r2+40(FP)
	BL	runtime·exitsyscall(SB)
	RET

TEXT ·RawSyscall(SB),NOSPLIT,$0-56
	MOVD	$syscall·RawSyscall(SB), R12
	MOVD	R12, CTR
	JMP	(CTR)

TEXT ·RawSyscall6(SB),NOSPLIT,$0-80
	MOVD	$syscall·RawSyscall6(SB), R12
	MOVD	R12, CTR
	JMP	(CTR)

TEXT ·RawSyscallNoError(SB),NOSPLIT,$0-48
	MOVD	a1+8(FP), R3
	MOVD	a2+16(FP), R4
	MOVD	a3+24(FP), R5
	MOVD	R0, R6
	MOVD	R0, R7
	MOVD	R0, R8
	MOVD	trap+0(FP), R9	// syscall entry
	SYSCALL R9
	MOVD	R3, r1+32(FP)
	MOVD	R4, r2+40(FP)
	RET
